package com.axsos.savetravels.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.axsos.savetravels.models.Expenses;
import com.axsos.savetravels.services.ExpensesService;
import jakarta.validation.Valid;

@Controller
public class MainController {
	 private final ExpensesService expensesService;
	    public MainController(ExpensesService expensesService){
	        this.expensesService = expensesService;
	    }
	@RequestMapping("/expenses")
	public String index(@ModelAttribute("expenses") Expenses expense, Model model) {
		
		 List<Expenses> expenses = expensesService.allExpenses();
		 model.addAttribute("expenses", expenses);
		 
		return "index.jsp";

	}
	
	  @PostMapping("/new") 
	  public String create(@Valid @ModelAttribute("expenses")
	   Expenses expense, BindingResult result, Model model) {
		  
	   if (result.hasErrors()){
		   List<Expenses> expenses = expensesService.allExpenses();
		      model.addAttribute("expenses", expenses);
		   return "index.jsp";
	   }
	   else{
		   expensesService.createExpense(expense); return
				"redirect:/expenses"; }
	  
	  }
	 
}
