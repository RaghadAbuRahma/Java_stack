package com.axsos.savetravels.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.axsos.savetravels.models.Expenses;
import com.axsos.savetravels.repositories.ExpensesRepositoy;



@Service
public class ExpensesService {
    private final ExpensesRepositoy expensesRepo;
    public ExpensesService(ExpensesRepositoy expensesRepo) {
        this.expensesRepo = expensesRepo;
    }
    
    
    public List<Expenses> allExpenses() {
        return expensesRepo.findAll();
    }
    public Expenses createExpense(Expenses expense) {
    	return expensesRepo.save(expense);
    }

}
